package net.infy.vrs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.infy.vrs.entity.VehicleDetails;
public interface VehicleRepository extends JpaRepository<VehicleDetails,Integer>{

}

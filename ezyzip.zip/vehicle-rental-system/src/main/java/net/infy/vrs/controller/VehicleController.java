package net.infy.vrs.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import net.infy.vrs.entity.VehicleDetails;
import net.infy.vrs.repository.VehicleRepository;

@Controller

public class VehicleController {
	
	@Autowired
	private VehicleRepository repo;

	@GetMapping("/")
	public String home()
	{
	  return "index";	
	}
	
	@PostMapping("/Add Vehicle")
	public String register(@ModelAttribute VehicleDetails u,HttpSession session)
	{
		System.out.println(u);
		
		repo.save(u);
		
		session.setAttribute("message", "Vehicle Register Sucessfully..");
		
		return "redirect:/";
	}
}

